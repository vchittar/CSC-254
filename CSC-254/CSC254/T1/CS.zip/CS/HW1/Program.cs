﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //System.out.println(Arrays.toString(prime_partitions(29,0)));
            List<int[]> result = prime_partitions(39, 0);
            Console.WriteLine("Trololo");
            foreach (int[] i in result)
            {
                for (int j = 0; j < i.Length; j++)
                {
                    Console.Write(" " + i[j]);
                }
                Console.WriteLine();
                //Console.WriteLine(string.Join(",", genprime(5)));
            }

            int[] primes = genprime(7);

            for (int i = 0; i < primes.Length; i++)
            {
                //Console.WriteLine(" " + primes[i]);
            }

        }

        public static List<int[]> prime_partitions(int n, int k)
        {
            //ArrayList<Integer[]> result = new ArrayList<Integer[]>();
            List<int[]> result = prime_partitions_rec(n, k);
            //Integer[] gen = prime_partitions_rec(n, k);
            List<int[]> gen = new List<int[]>();
            //if(result.isEmpty()){
            int[] primes = genprime(n);
            int i = k;
            while (i < primes.Length)
            {
                List<int> genList = new List<int>();
                gen = prime_partitions_rec(n - primes[i], i+1);
                //System.out.println("Prime is "+primes[i]+", gen is "+Arrays.`(gen)+", List "+genList.toString());
                if (gen != null)
                {
                    //genList.addAll(Arrays.asList(gen));
                    //gen = genList.toArray(new Integer[0]);
                    //result.add(gen);
                    foreach (int[] index in gen)
                    {
                        genList.Add(primes[i]);
                        genList.AddRange(index);
                        result.Add(genList.ToArray());
                        genList.Clear();
                    }
                }
                //System.out.println("n is "+n+" i is "+i +" length is "+ primes.length);
                i++;

            }
            //}
            //int iteration = 0;
            for (int m = 0; m < result.Count; m++)
            {
                int[] index = result[m];
                for (int j = 0; j < index.Length; j++)
                {
                    List<int[]> tempList = prime_partitions(index[j], 0);
                    foreach (int[] x in tempList)
                    {
                        //System.out.println("j is "+j + " length is "+index.length + " tempList is "+tempList.size());
                        List<int> temp = new List<int>();
                        temp.AddRange(x);
                        List<int> indexTemp = new List<int>();
                        indexTemp.AddRange(index);
                        indexTemp.RemoveAt(j);
                        temp.AddRange(indexTemp);
                        /*Console.WriteLine("Numbers being added are:");
                        for (int o = 0; o < temp.Count; o++)
                        {
                            Console.Write(" " + temp.ToArray()[o]);
                        }
                        Console.WriteLine();*/
                        int[] sorted = temp.ToArray();
                        Array.Sort(sorted);
                        temp.Clear();
                        temp.AddRange(sorted);
                        //temp.Distinct().Count()
                        //genList.add(primes[i]);
                        //genList.addAll(Arrays.asList(index));
                        //System.out.println(temp.toString());
                        if (temp.Count == temp.Distinct().Count())
                        {
                            bool duplicate = false;
                            foreach (int[] current in result)
                            {
                                if (current.SequenceEqual(temp.ToArray()))
                                {
                                    //Console.WriteLine("Found");
                                    duplicate = true;
                                    break;
                                }
                            }
                            if (!duplicate)
                            {
                                /*Console.WriteLine("Numbers being added are:");
                                for (int o = 0; o < temp.Count; o++)
                                {
                                    Console.Write(" " + temp.ToArray()[o]);
                                }
                                Console.WriteLine();*/
                                result.Add(temp.ToArray());
                            }
                        }
                        //genList.clear();
                    }
                }

            }
            return result;
        }

        public static bool hasInternalDuplicate(List<int> input)
        {
            for (int i = 0; i < input.Count; i++)
            {
                for (int j = 1; j < input.Count; j++)
                {
                    Console.WriteLine("input[i]: " + input[i] + " input[j]: " + input[j]);
                    if (i != j && input[i] == input[j])
                    {
                        Console.WriteLine("Dup found!!");
                        return true;
                    }
                }
            }
            return false;
        }


        public static List<int[]> prime_partitions_rec(int input, int k)
        {
            int[] primes = genprime(input);
            /*Console.WriteLine("Input is "+input+", Primes are:");
            for (int i = 0; i < primes.Length; i++)
            {
                Console.Write(" " + primes[i]);
            }
            Console.WriteLine();*/
            List<int[]> result = new List<int[]>();
            for (int i = k; i < primes.Length; i++)
            {
                //System.out.println("i is "+ i);
                for (int j = primes.Length - 1; j > i; j--)
                {
                    //Console.WriteLine("Input = "+input+", primes[i] = "+primes[i]+", primes[j]"+primes[j]);
                    if (primes[i] + primes[j] == input)
                    {
                        //Console.WriteLine("Found!!");
                        //return new Integer[]{primes[i], primes[j]};
                        result.Add(new int[] { primes[i], primes[j] });
                    }
                }
            }
            return result;
        }

        //Cite: naive algorithm here: https://en.wikipedia.org/wiki/Primality_test
        public static int[] genprime(int max)
        {
            List<int> primes = new List<int>();
            for (int i = 2; i < max; i++)
            {
                if (checkprime(i))
                {
                    primes.Add(i);
                }
            }
            return primes.ToArray();
        }

        public static bool checkprime(int input)
        {
            if (input <= 1)
            {
                return false;
            }
            else if (input <= 3)
            {
                return true;
            }
            else if (input % 2 == 0 || input % 3 == 0)
            {
                return false;
            }
            for (int i = 5; i * i <= input; i += 6)
            {
                if (input % i == 0 || input % (i + 2) == 0)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
