#include <stdio.h>

void fred()
{
    printf("test\n");
}

void main() 
{
    fred();
}
