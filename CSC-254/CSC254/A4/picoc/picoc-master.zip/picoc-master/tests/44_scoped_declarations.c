#include <stdio.h>

int a;

for (a = 0; a < 2; a++)
{
    int b = a;
}

printf("it's all good\n");

void main() {}
